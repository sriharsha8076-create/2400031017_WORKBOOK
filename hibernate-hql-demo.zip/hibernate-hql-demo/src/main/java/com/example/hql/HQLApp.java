package com.example.hql;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class HQLApp {

    public static void main(String[] args) {

        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        // ---------- INSERT 5–8 PRODUCTS ----------
        session.save(new Product("Laptop", "Electronics", 55000, 10));
        session.save(new Product("Mouse", "Electronics", 800, 50));
        session.save(new Product("Keyboard", "Electronics", 2500, 20));
        session.save(new Product("Chair", "Furniture", 7000, 5));
        session.save(new Product("Table", "Furniture", 12000, 3));
        session.save(new Product("Phone", "Electronics", 30000, 15));

        tx.commit();

        // ---------- SORT BY PRICE ASC ----------
        Query<Product> q1 = session.createQuery(
                "from Product p order by p.price asc", Product.class);
        List<Product> ascList = q1.list();

        // ---------- SORT BY PRICE DESC ----------
        Query<Product> q2 = session.createQuery(
                "from Product p order by p.price desc", Product.class);
        List<Product> descList = q2.list();

        // ---------- SORT BY QUANTITY (HIGHEST FIRST) ----------
        Query<Product> q3 = session.createQuery(
                "from Product p order by p.quantity desc", Product.class);
        List<Product> qtyList = q3.list();

        // ---------- PAGINATION ----------
        Query<Product> q4 = session.createQuery("from Product", Product.class);
        q4.setFirstResult(0);
        q4.setMaxResults(3);
        List<Product> first3 = q4.list();

        Query<Product> q5 = session.createQuery("from Product", Product.class);
        q5.setFirstResult(3);
        q5.setMaxResults(3);
        List<Product> next3 = q5.list();

        // ---------- AGGREGATE FUNCTIONS ----------
        Long totalCount = session.createQuery(
                "select count(p) from Product p", Long.class).uniqueResult();

        Long availableCount = session.createQuery(
                "select count(p) from Product p where p.quantity > 0",
                Long.class).uniqueResult();

        List<Object[]> countByDesc = session.createQuery(
                "select p.description, count(p) from Product p group by p.description",
                Object[].class).list();

        Object[] minMax = session.createQuery(
                "select min(p.price), max(p.price) from Product p",
                Object[].class).uniqueResult();

        // ---------- GROUP BY DESCRIPTION ----------
        List<Object[]> groupDesc = session.createQuery(
                "select p.description, count(p) from Product p group by p.description",
                Object[].class).list();

        // ---------- PRICE RANGE ----------
        Query<Product> q6 = session.createQuery(
                "from Product p where p.price between 5000 and 40000",
                Product.class);
        List<Product> priceRange = q6.list();

        // ---------- LIKE OPERATIONS ----------
        List<Product> startsWith = session.createQuery(
                "from Product p where p.name like 'L%'", Product.class).list();

        List<Product> endsWith = session.createQuery(
                "from Product p where p.name like '%e'", Product.class).list();

        List<Product> contains = session.createQuery(
                "from Product p where p.name like '%top%'", Product.class).list();

        List<Product> exactLength = session.createQuery(
                "from Product p where length(p.name) = 5",
                Product.class).list();

        session.close();
    }
}
